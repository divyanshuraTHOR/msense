package com.maintenance.system.exception;

/**
 * This is Exception class to throw InvalidEmailFormatException
 *
 * @author Gordhan Goyal, Sunil, Brijesh
 */
public class InvalidEmailFormatException extends RuntimeException {
}
