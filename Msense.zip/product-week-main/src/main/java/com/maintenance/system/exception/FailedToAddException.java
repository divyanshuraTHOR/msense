package com.maintenance.system.exception;

/**
 * This is Exception class throws FailedToAddException
 *
 * @author Gordhan Goyal
 */
public class FailedToAddException extends RuntimeException {
}
