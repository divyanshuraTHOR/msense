package com.maintenance.system.exception;


/**
 * This UserNotFoundException class
 *
 * @author Sunil Hansda
 */

public class UserNotFoundException extends RuntimeException {
}
