package com.maintenance.system.exception;

/**
 * This is Exception class in case if incorrect is password
 *
 * @author Gordhan Goyal
 */
public class MismatchedPasswordException extends RuntimeException {
}
