package com.maintenance.system.exception;

/**
 * This is exception class throws UserRegistrationException
 *
 * @author Gordhan Goyal
 */
public class UserRegistrationException extends RuntimeException {

}
