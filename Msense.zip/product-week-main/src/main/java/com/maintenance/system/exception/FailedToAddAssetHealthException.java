package com.maintenance.system.exception;

/**
 * This is Exception class, throws FailedToAddAssetHealthException
 *
 * @author Gordhan Goyal
 */
public class FailedToAddAssetHealthException extends RuntimeException {
}
